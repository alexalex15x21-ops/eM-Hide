package com.em.hide

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.provider.MediaStore
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import javax.crypto.Cipher

/**
 * استقبال "مشاركة" من أي تطبيق (المعرض، الملفات...) ← تأكيد بالبصمة أو كلمة السر ← تشفير وإخفاء تلقائي.
 */
class ShareActivity : Activity() {

    private val BG = 0xFF0F172A.toInt()
    private val GREEN = 0xFF16A34A.toInt()
    private val BLUE = 0xFF2563EB.toInt()
    private val GRAY = 0xFF334155.toInt()
    private val MUTED = 0xFF94A3B8.toInt()
    private val REQ_DELETE = 201

    private var uris: List<Uri> = emptyList()
    private var busy = false
    private var wantAutoBio = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Vault.key = null // لازم تأكيد جديد في كل مشاركة
        uris = extract(intent)
        when {
            !Vault.isSetup(this) -> showMessage("افتح eM Hide الأول وأنشئ كلمة سر، وبعدها شارك الملفات.", true)
            uris.isEmpty() -> showMessage("مفيش ملفات (صور / فيديوهات / ملفات) في المشاركة دي.", false)
            else -> showAuth(true)
        }
    }

    override fun onResume() {
        super.onResume()
        if (wantAutoBio) { wantAutoBio = false; loginBio() }
    }

    override fun onDestroy() {
        Vault.key = null
        super.onDestroy()
    }

    private fun extract(i: Intent): List<Uri> {
        val res = LinkedHashSet<Uri>()
        i.clipData?.let { c ->
            for (k in 0 until c.itemCount) c.getItemAt(k).uri?.let { res.add(it) }
        }
        if (res.isEmpty()) {
            @Suppress("DEPRECATION")
            if (i.action == Intent.ACTION_SEND_MULTIPLE) {
                i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { res.addAll(it) }
            } else {
                i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { res.add(it) }
            }
        }
        return res.toList()
    }

    // ---------------- واجهة ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun root() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(BG)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(20), dp(30), dp(20), dp(20))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        layoutParams = ViewGroup.LayoutParams(-1, -1)
    }

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun btn(t: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 15f
        background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(color) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        setOnClickListener { onClick() }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun finishLocked() {
        Vault.key = null
        finish()
    }

    private fun showMessage(msg: String, offerOpen: Boolean) {
        val r = root()
        r.addView(label("🔒", 48f))
        r.addView(label(msg, 16f).apply { setPadding(0, dp(12), 0, dp(12)) })
        if (offerOpen) r.addView(btn("فتح eM Hide", GREEN) {
            startActivity(Intent(this, MainActivity::class.java)); finishLocked()
        })
        r.addView(btn("إغلاق", GRAY) { finishLocked() })
        setContentView(r)
    }

    private fun showAuth(autoBio: Boolean) {
        val r = root()
        r.addView(label("🔒", 48f))
        r.addView(label("إخفاء في eM Hide", 24f, Color.WHITE, true))
        r.addView(label("${uris.size} ملف جاهزين للإخفاء\nأكّد هويتك عشان يتشفّروا", 14f, MUTED).apply {
            setPadding(0, dp(8), 0, dp(16))
        })
        val pw = EditText(this).apply {
            hint = "كلمة السر"
            setHintTextColor(MUTED)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        r.addView(pw)
        r.addView(btn("تأكيد وإخفاء", GREEN) {
            if (Vault.login(this, pw.text.toString())) startHide() else toast("كلمة السر غير صحيحة")
        })
        val bioOn = Bio.enabled(this) && Bio.mode(this) != 0
        if (bioOn) r.addView(btn("👆 تأكيد بالبصمة", BLUE) { loginBio() })
        r.addView(btn("إلغاء", GRAY) { finishLocked() })
        setContentView(r)
        wantAutoBio = bioOn && autoBio
    }

    // ---------------- البصمة ----------------

    private fun bioPrompt(cipher: Cipher, strong: Boolean, onOk: (Cipher) -> Unit) {
        busy = true
        val b = BiometricPrompt.Builder(this)
            .setTitle("تأكيد إخفاء الملفات")
            .setNegativeButton("إلغاء", mainExecutor) { _, _ -> busy = false }
        if (!strong && Build.VERSION.SDK_INT >= 30) {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        }
        val p = b.build()
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                busy = false
                if (strong) r.cryptoObject?.cipher?.let(onOk) else onOk(cipher)
            }

            override fun onAuthenticationError(code: Int, msg: CharSequence?) {
                busy = false
                if (code != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED &&
                    code != BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                ) toast(msg.toString())
            }
        }
        if (strong) p.authenticate(BiometricPrompt.CryptoObject(cipher), CancellationSignal(), mainExecutor, cb)
        else p.authenticate(CancellationSignal(), mainExecutor, cb)
    }

    private fun loginBio() {
        try {
            val strong = Bio.isStrong(this)
            val c = Bio.decCipher(this)
            bioPrompt(c, strong) { ci ->
                try {
                    Vault.unlockWith(Bio.load(this, ci))
                    startHide()
                } catch (e: Exception) { toast("فشلت البصمة — استخدم كلمة السر") }
            }
        } catch (e: KeyPermanentlyInvalidatedException) {
            Bio.disable(this)
            toast("البصمات المسجّلة اتغيّرت — استخدم كلمة السر")
        } catch (e: Exception) {
            toast("البصمة غير متاحة — استخدم كلمة السر")
        }
    }

    // ---------------- الإخفاء ----------------

    private fun startHide() {
        var ok = 0
        var fail = 0
        var manual = 0
        val toDel = ArrayList<Uri>()
        val d = ProgressDlg(this, "جاري التشفير والإخفاء")
        Thread {
            val infos = uris.map { try { Hider.info(this, it) } catch (e: Exception) { Triple("file", 0L, "application/octet-stream") } }
            val total = infos.sumOf { maxOf(it.second, 1L) }
            var base = 0L
            for ((idx, u) in uris.withIndex()) {
                val (name, size, mime) = infos[idx]
                val label = "${idx + 1}/${uris.size} • $name"
                d.update(base, total, label)
                try {
                    val emh = contentResolver.openInputStream(u)!!.use {
                        Vault.encrypt(this, it, name, mime, size, onProgress = { c -> d.update(base + c, total, label) })
                    }
                    ok++
                    try { Vault.makeThumbFromUri(this, u, mime, emh) } catch (_: Exception) {}
                    if (!Hider.tryDelete(this, u)) {
                        val mu = Hider.toMediaUri(u)
                        if (mu != null) toDel.add(mu) else manual++
                    }
                } catch (e: Exception) { fail++ }
                base += maxOf(size, 1L)
            }
            d.update(total, total, "تم")
            runOnUiThread { d.dismiss(); done(ok, fail, manual, toDel) }
        }.start()
    }

    private fun done(ok: Int, fail: Int, manual: Int, toDel: List<Uri>) {
        var msg = "✅ تم تشفير وإخفاء $ok ملف"
        if (fail > 0) msg += "\nفشل: $fail"
        if (manual > 0) msg += "\n$manual ملف النسخة الأصلية منه لسه موجودة في التطبيق المصدر (زي Google Photos) — احذفها يدويًا"
        if (toDel.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
            toast("تم إخفاء $ok ملف — وافق على حذف النسخ الأصلية")
            try {
                busy = true
                val pi = MediaStore.createDeleteRequest(contentResolver, toDel)
                startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
                return
            } catch (e: Exception) {
                busy = false
                msg += "\nاحذف النسخ الأصلية من المعرض يدويًا"
            }
        } else if (toDel.isNotEmpty()) {
            var n = 0
            for (u in toDel) try { if (contentResolver.delete(u, null, null) > 0) n++ } catch (_: Exception) {}
            if (n < toDel.size) msg += "\nاحذف النسخ الأصلية من المعرض يدويًا"
        }
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("تمام") { _, _ -> finishLocked() }
            .show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_DELETE) {
            busy = false
            toast(
                if (res == RESULT_OK) "تم الإخفاء وحذف النسخ الأصلية ✅"
                else "تم الإخفاء — النسخ الأصلية لسه في المعرض، احذفها يدويًا"
            )
            finishLocked()
        }
    }
}
