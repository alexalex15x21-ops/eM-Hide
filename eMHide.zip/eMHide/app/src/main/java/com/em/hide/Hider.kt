package com.em.hide

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns

/** أدوات مشتركة لإخفاء ملف من Uri وحذف الأصل بعد التشفير */
object Hider {
    fun info(c: Context, u: Uri): Triple<String, Long, String> {
        var name: String? = null
        var size = 0L
        try {
            c.contentResolver.query(u, null, null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val n = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val s = cur.getColumnIndex(OpenableColumns.SIZE)
                    if (n >= 0) name = cur.getString(n)
                    if (s >= 0) size = cur.getLong(s)
                }
            }
        } catch (_: Exception) {
        }
        val mime = c.contentResolver.getType(u) ?: "application/octet-stream"
        return Triple(name ?: "file_${System.currentTimeMillis()}", size, mime)
    }

    fun tryDelete(c: Context, u: Uri): Boolean {
        try { if (DocumentsContract.deleteDocument(c.contentResolver, u)) return true } catch (_: Exception) {}
        try { if (c.contentResolver.delete(u, null, null) > 0) return true } catch (_: Exception) {}
        return false
    }

    /** تحويل Uri معرض الصور لـ MediaStore Uri عشان نطلب إذن الحذف */
    fun toMediaUri(u: Uri): Uri? {
        val auth = u.authority ?: return null
        try {
            if (auth == "media") return u
            if (auth == "com.android.providers.media.documents") {
                val p = DocumentsContract.getDocumentId(u).split(":")
                if (p.size != 2) return null
                val base = when (p[0]) {
                    "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    else -> null
                }
                return base?.let { ContentUris.withAppendedId(it, p[1].toLong()) }
            }
        } catch (_: Exception) {
        }
        return null
    }
}
