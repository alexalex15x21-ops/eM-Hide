package com.em.hide

import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object Bio {
    private const val ALIAS = "emhide_bio_key"
    private fun prefs(c: Context) = c.getSharedPreferences("emhide", Context.MODE_PRIVATE)

    /** 0 = غير متاح، 1 = بصمة قوية (مربوطة بالهاردوير)، 2 = بصمة عادية */
    fun mode(c: Context): Int = try {
        val bm = c.getSystemService(BiometricManager::class.java)
        if (bm == null) 0
        else if (Build.VERSION.SDK_INT >= 30) {
            when {
                bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS -> 1
                bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS -> 2
                else -> 0
            }
        } else if (bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS) 1 else 0
    } catch (_: Exception) {
        0
    }

    fun reason(c: Context): String = try {
        val bm = c.getSystemService(BiometricManager::class.java)
        val code = if (Build.VERSION.SDK_INT >= 30)
            bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) else bm.canAuthenticate()
        when (code) {
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "مفيش بصمة مسجّلة على الموبايل"
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "الجهاز مفيهوش قارئ بصمة"
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "قارئ البصمة غير متاح دلوقتي"
            else -> "البصمة غير متاحة (كود $code)"
        }
    } catch (e: Exception) {
        "تعذّر الوصول للبصمة: ${e.message}"
    }

    fun enabled(c: Context) = prefs(c).contains("bio_iv")
    fun isStrong(c: Context) = prefs(c).getBoolean("bio_strong", true)

    fun disable(c: Context) {
        prefs(c).edit().remove("bio_iv").remove("bio_data").remove("bio_strong").commit()
        try {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
    }

    fun encCipher(auth: Boolean): Cipher {
        try {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val b = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
        if (auth) b.setUserAuthenticationRequired(true).setInvalidatedByBiometricEnrollment(true)
        kg.init(b.build())
        val key = kg.generateKey()
        return Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key) }
    }

    fun decCipher(c: Context): Cipher {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = ks.getKey(ALIAS, null) as SecretKey
        val iv = Base64.decode(prefs(c).getString("bio_iv", "") ?: "", Base64.NO_WRAP)
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        }
    }

    fun save(c: Context, cipher: Cipher, keyBytes: ByteArray, strong: Boolean) {
        val ct = cipher.doFinal(keyBytes)
        prefs(c).edit()
            .putString("bio_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("bio_data", Base64.encodeToString(ct, Base64.NO_WRAP))
            .putBoolean("bio_strong", strong)
            .commit()
    }

    fun load(c: Context, cipher: Cipher): ByteArray {
        val data = Base64.decode(prefs(c).getString("bio_data", "") ?: "", Base64.NO_WRAP)
        return cipher.doFinal(data)
    }
}
