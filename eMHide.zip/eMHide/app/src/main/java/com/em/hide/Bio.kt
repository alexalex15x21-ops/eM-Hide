package com.em.hide

import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * البصمة: مفتاح التشفير بيتخزن مغلّف بمفتاح داخل Android Keystore
 * ومش بيتفتح غير بعد التحقق بالبصمة (محمي بالهاردوير).
 */
object Bio {
    private const val ALIAS = "emhide_bio_key"

    private fun prefs(c: Context) = c.getSharedPreferences("emhide", Context.MODE_PRIVATE)

    fun available(c: Context): Boolean = try {
        c.getSystemService(BiometricManager::class.java)?.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
    } catch (_: Exception) {
        false
    }

    fun enabled(c: Context) = prefs(c).contains("bio_iv")

    fun disable(c: Context) {
        prefs(c).edit().remove("bio_iv").remove("bio_data").commit()
        try {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
    }

    fun encCipher(): Cipher {
        try {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true)
                .build()
        )
        val key = kg.generateKey()
        return Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key) }
    }

    fun decCipher(c: Context): Cipher {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = ks.getKey(ALIAS, null) as SecretKey
        val iv = Base64.decode(prefs(c).getString("bio_iv", "") ?: "", Base64.NO_WRAP)
        return Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        }
    }

    fun save(c: Context, cipher: Cipher, keyBytes: ByteArray) {
        val ct = cipher.doFinal(keyBytes)
        prefs(c).edit()
            .putString("bio_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("bio_data", Base64.encodeToString(ct, Base64.NO_WRAP))
            .commit()
    }

    fun load(c: Context, cipher: Cipher): ByteArray {
        val data = Base64.decode(prefs(c).getString("bio_data", "") ?: "", Base64.NO_WRAP)
        return cipher.doFinal(data)
    }
}
