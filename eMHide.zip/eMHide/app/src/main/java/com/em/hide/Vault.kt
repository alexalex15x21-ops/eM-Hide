package com.em.hide

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object Vault {
    @Volatile
    var key: SecretKeySpec? = null

    class Meta(val file: File, val name: String, val mime: String, val size: Long, val hdr: Int) {
        /** 0 = صور، 1 = فيديوهات، 2 = ملفات */
        val cat: Int
            get() = when {
                mime.startsWith("image/") -> 0
                mime.startsWith("video/") -> 1
                else -> 2
            }
        val thumbFile: File get() = File(file.parentFile, file.nameWithoutExtension + ".thb")
    }

    class Opened(val meta: Meta, val stream: InputStream)
    class Thumb(val bmp: Bitmap, val dur: Long)

    private class CountIn(i: InputStream) : FilterInputStream(i) {
        var count = 0
        override fun read(): Int { val r = super.read(); if (r >= 0) count++; return r }
        override fun read(b: ByteArray, o: Int, l: Int): Int { val r = super.read(b, o, l); if (r > 0) count += r; return r }
    }

    private fun prefs(c: Context) = c.getSharedPreferences("emhide", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "vault").apply { mkdirs() }
    private fun trashDir(c: Context) = File(c.filesDir, "trash").apply { mkdirs() }
    private const val DAY = 24L * 60 * 60 * 1000
    const val TRASH_DAYS = 30
    const val FOLDER = "eM Hide"   // الفولدر اللي بترجع فيه الملفات عند إلغاء الإخفاء

    fun isSetup(c: Context) = prefs(c).contains("salt")
    fun keyBytes(): ByteArray = (key ?: throw IllegalStateException("locked")).encoded
    fun unlockWith(b: ByteArray) { key = SecretKeySpec(b, "AES") }

    private fun derive(pw: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 120000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun sha(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    fun setup(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val k = derive(pw, salt)
        prefs(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("check", Base64.encodeToString(sha(k), Base64.NO_WRAP))
            .commit()
        key = SecretKeySpec(k, "AES")
    }

    fun login(c: Context, pw: String): Boolean {
        val p = prefs(c)
        val salt = Base64.decode(p.getString("salt", "") ?: "", Base64.NO_WRAP)
        val check = Base64.decode(p.getString("check", "") ?: "", Base64.NO_WRAP)
        val k = derive(pw, salt)
        val ok = MessageDigest.isEqual(sha(k), check)
        if (ok) key = SecretKeySpec(k, "AES")
        return ok
    }

    // ---------- تشفير الملفات ----------

    fun encrypt(
        c: Context, input: InputStream, name: String, mime: String, size: Long,
        onProgress: ((Long) -> Unit)? = null
    ): File {
        val k = key ?: throw IllegalStateException("locked")
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, k, IvParameterSpec(iv))
        val out = File(dir(c), UUID.randomUUID().toString() + ".emh")
        try {
            FileOutputStream(out).use { fos ->
                fos.write(iv)
                val dos = DataOutputStream(CipherOutputStream(fos, cipher).buffered())
                dos.writeUTF(name)
                dos.writeUTF(mime)
                dos.writeLong(size)
                val buf = ByteArray(64 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    dos.write(buf, 0, n)
                    total += n
                    onProgress?.invoke(total)
                }
                dos.close()
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        return out
    }

    fun open(f: File): Opened {
        val k = key ?: throw IllegalStateException("locked")
        val fis = FileInputStream(f)
        try {
            val iv = ByteArray(16)
            DataInputStream(fis).readFully(iv)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, k, IvParameterSpec(iv))
            val cnt = CountIn(CipherInputStream(fis, cipher))
            val dis = DataInputStream(cnt)
            val name = dis.readUTF()
            val mime = dis.readUTF()
            val size = dis.readLong()
            return Opened(Meta(f, name, mime, size, cnt.count), dis)
        } catch (e: Exception) {
            fis.close()
            throw e
        }
    }

    fun list(c: Context, trash: Boolean = false): List<Meta> {
        val files = (if (trash) trashDir(c) else dir(c)).listFiles { f -> f.extension == "emh" } ?: return emptyList()
        val res = ArrayList<Meta>()
        for (f in files) {
            try {
                val o = open(f)
                o.stream.close()
                res.add(o.meta)
            } catch (_: Exception) {
            }
        }
        return res.sortedByDescending { it.file.lastModified() }
    }

    /** حذف نهائي */
    fun deleteForever(m: Meta) {
        m.file.delete()
        m.thumbFile.delete()
    }

    private fun move(from: File, toDir: File) {
        if (!from.exists()) return
        val to = File(toDir, from.name)
        if (!from.renameTo(to)) { from.copyTo(to, true); from.delete() }
        to.setLastModified(System.currentTimeMillis())
    }

    /** نقل لسلة المحذوفات (30 يوم) */
    fun trash(c: Context, m: Meta) {
        val td = trashDir(c)
        val th = m.thumbFile
        move(m.file, td)
        move(th, td)
    }

    /** استرجاع من السلة للخزنة */
    fun restoreFromTrash(c: Context, m: Meta) {
        val vd = dir(c)
        val th = m.thumbFile
        move(m.file, vd)
        move(th, vd)
    }

    /** مسح اللي عدّى عليه أكتر من 30 يوم */
    fun purgeOld(c: Context) {
        val cutoff = System.currentTimeMillis() - TRASH_DAYS * DAY
        trashDir(c).listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    fun daysLeft(m: Meta): Int =
        (TRASH_DAYS - (System.currentTimeMillis() - m.file.lastModified()) / DAY).toInt().coerceAtLeast(0)

    private fun encryptBytes(bytes: ByteArray, out: File) {
        val k = key ?: throw IllegalStateException("locked")
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, k, IvParameterSpec(iv))
        out.writeBytes(iv + cipher.doFinal(bytes))
    }

    private fun decryptBytes(f: File): ByteArray {
        val k = key ?: throw IllegalStateException("locked")
        val all = f.readBytes()
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, k, IvParameterSpec(all, 0, 16))
        return cipher.doFinal(all, 16, all.size - 16)
    }

    // ---------- الصور المصغّرة ----------

    private fun rotate(b: Bitmap, o: Int): Bitmap {
        val deg = when (o) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (deg == 0f) return b
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    fun decodeSampled(open: () -> InputStream?, max: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
        o.inJustDecodeBounds = false
        o.inSampleSize = s
        val b = open()?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val orient = open()?.use {
            try { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } catch (_: Exception) { 1 }
        } ?: 1
        return rotate(b, orient)
    }

    private fun scaleTo(b: Bitmap, max: Int): Bitmap {
        val s = max.toFloat() / maxOf(b.width, b.height)
        if (s >= 1f) return b
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
    }

    private fun frameOf(r: MediaMetadataRetriever): Thumb? {
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val f = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            ?: r.getFrameAtTime(0L) ?: return null
        return Thumb(scaleTo(f, 360), dur)
    }

    private fun saveThumb(emh: File, t: Thumb) {
        val jpg = ByteArrayOutputStream()
        t.bmp.compress(Bitmap.CompressFormat.JPEG, 80, jpg)
        val baos = ByteArrayOutputStream()
        val d = DataOutputStream(baos)
        d.writeLong(t.dur)
        d.writeInt(jpg.size())
        d.write(jpg.toByteArray())
        d.flush()
        encryptBytes(baos.toByteArray(), File(emh.parentFile, emh.nameWithoutExtension + ".thb"))
    }

    /** وقت الإخفاء: نعمل الصورة المصغّرة من الملف الأصلي مباشرة (أسرع) */
    fun makeThumbFromUri(c: Context, uri: Uri, mime: String, emh: File) {
        val t: Thumb? = when {
            mime.startsWith("image/") ->
                decodeSampled({ c.contentResolver.openInputStream(uri) }, 360)?.let { Thumb(it, -1L) }
            mime.startsWith("video/") -> {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(c, uri); frameOf(r) } finally { r.release() }
            }
            else -> null
        }
        if (t != null) saveThumb(emh, t)
    }

    fun loadThumb(m: Meta): Thumb? {
        if (!m.thumbFile.exists()) return null
        val d = DataInputStream(ByteArrayInputStream(decryptBytes(m.thumbFile)))
        val dur = d.readLong()
        val bytes = ByteArray(d.readInt())
        d.readFully(bytes)
        val b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        return Thumb(b, dur)
    }

    /** للملفات المخفية قبل التحديث (مالهاش صورة مصغّرة) */
    fun generateThumb(m: Meta): Thumb? {
        val k = key ?: return null
        val t: Thumb? = when {
            m.mime.startsWith("image/") ->
                decodeSampled({ try { open(m.file).stream } catch (_: Exception) { null } }, 360)?.let { Thumb(it, -1L) }
            m.mime.startsWith("video/") -> {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(VaultDataSource(m, k)); frameOf(r) } finally { r.release() }
            }
            else -> null
        }
        if (t != null) try { saveThumb(m.file, t) } catch (_: Exception) {}
        return t
    }

    fun loadFull(m: Meta): Bitmap? =
        decodeSampled({ try { open(m.file).stream } catch (_: Exception) { null } }, 2048)

    // ---------- إلغاء الإخفاء ----------

    fun restore(c: Context, m: Meta, onProgress: ((Long) -> Unit)? = null): Boolean {
        val mime = m.mime
        val target = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, target.second + "/" + FOLDER)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val r = c.contentResolver
        val uri = r.insert(target.first, cv) ?: return false
        try {
            val o = open(m.file)
            o.stream.use { ins ->
                r.openOutputStream(uri)!!.use { out ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                        onProgress?.invoke(total)
                    }
                }
            }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            r.update(uri, done, null, null)
        } catch (e: Exception) {
            try { r.delete(uri, null, null) } catch (_: Exception) {}
            return false
        }
        deleteForever(m)
        return true
    }
}
