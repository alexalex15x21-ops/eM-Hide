package com.em.hide

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * خزنة مشفرة: كل ملف يتخزن داخل مساحة التطبيق الخاصة (مش بتظهر في المعرض ولا مدير الملفات)
 * ومشفر AES-256 بمفتاح مشتق من كلمة السر. اسم الملف الأصلي ونوعه متشفرين جوه الملف نفسه.
 */
object Vault {
    @Volatile
    var key: SecretKeySpec? = null

    fun keyBytes(): ByteArray = (key ?: throw IllegalStateException("locked")).encoded
    fun unlockWith(b: ByteArray) { key = SecretKeySpec(b, "AES") }

    class Meta(val file: File, val name: String, val mime: String, val size: Long)
    class Opened(val meta: Meta, val stream: InputStream)

    private fun prefs(c: Context) = c.getSharedPreferences("emhide", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "vault").apply { mkdirs() }

    fun isSetup(c: Context) = prefs(c).contains("salt")

    private fun derive(pw: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 120000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun sha(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    fun setup(c: Context, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val k = derive(pw, salt)
        prefs(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("check", Base64.encodeToString(sha(k), Base64.NO_WRAP))
            .commit()
        key = SecretKeySpec(k, "AES")
    }

    fun login(c: Context, pw: String): Boolean {
        val p = prefs(c)
        val salt = Base64.decode(p.getString("salt", "") ?: "", Base64.NO_WRAP)
        val check = Base64.decode(p.getString("check", "") ?: "", Base64.NO_WRAP)
        val k = derive(pw, salt)
        val ok = MessageDigest.isEqual(sha(k), check)
        if (ok) key = SecretKeySpec(k, "AES")
        return ok
    }

    fun encrypt(c: Context, input: InputStream, name: String, mime: String, size: Long) {
        val k = key ?: throw IllegalStateException("locked")
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, k, IvParameterSpec(iv))
        val out = File(dir(c), UUID.randomUUID().toString() + ".emh")
        try {
            FileOutputStream(out).use { fos ->
                fos.write(iv)
                val dos = DataOutputStream(CipherOutputStream(fos, cipher).buffered())
                dos.writeUTF(name)
                dos.writeUTF(mime)
                dos.writeLong(size)
                input.copyTo(dos)
                dos.close()
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
    }

    fun open(f: File): Opened {
        val k = key ?: throw IllegalStateException("locked")
        val fis = FileInputStream(f)
        try {
            val iv = ByteArray(16)
            DataInputStream(fis).readFully(iv)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, k, IvParameterSpec(iv))
            val dis = DataInputStream(BufferedInputStream(CipherInputStream(fis, cipher)))
            val name = dis.readUTF()
            val mime = dis.readUTF()
            val size = dis.readLong()
            return Opened(Meta(f, name, mime, size), dis)
        } catch (e: Exception) {
            fis.close()
            throw e
        }
    }

    fun list(c: Context): List<Meta> {
        val files = dir(c).listFiles { f -> f.extension == "emh" } ?: return emptyList()
        val res = ArrayList<Meta>()
        for (f in files) {
            try {
                val o = open(f)
                o.stream.close()
                res.add(o.meta)
            } catch (_: Exception) {
            }
        }
        return res.sortedBy { it.name.lowercase() }
    }

    /** إلغاء الإخفاء: فك التشفير ورجوع الملف للمعرض / التنزيلات */
    fun restore(c: Context, m: Meta): Boolean {
        val mime = m.mime
        val target = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, target.second)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val r = c.contentResolver
        val uri = r.insert(target.first, cv) ?: return false
        try {
            val o = open(m.file)
            o.stream.use { ins ->
                r.openOutputStream(uri)!!.use { ins.copyTo(it) }
            }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            r.update(uri, done, null, null)
        } catch (e: Exception) {
            try { r.delete(uri, null, null) } catch (_: Exception) {}
            return false
        }
        m.file.delete()
        return true
    }
}
