package com.em.hide

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/** نافذة تقدّم بنسبة مئوية (للتشفير وإلغاء التشفير) */
class ProgressDlg(private val act: Activity, title: String) {
    private val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 1000
        isIndeterminate = false
    }
    private val pct = TextView(act).apply {
        text = "0%"
        textSize = 28f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
    }
    private val info = TextView(act).apply {
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(0xFF94A3B8.toInt())
        maxLines = 2
    }
    private val dlg: AlertDialog
    private var last = 0L

    init {
        val d = act.resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        box.addView(pct)
        box.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * d).toInt() })
        box.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * d).toInt() })
        dlg = AlertDialog.Builder(act).setTitle(title).setView(box).setCancelable(false).create()
        dlg.show()
    }

    /** done/total بالبايت — بيتم تقليل عدد التحديثات عشان الأداء */
    fun update(done: Long, total: Long, text: String) {
        val now = System.currentTimeMillis()
        if (now - last < 80 && done < total) return
        last = now
        val p = if (total > 0) (done * 1000 / total).toInt().coerceIn(0, 1000) else 0
        act.runOnUiThread {
            bar.progress = p
            pct.text = "${p / 10}%"
            info.text = text
        }
    }

    fun dismiss() {
        act.runOnUiThread { try { dlg.dismiss() } catch (_: Exception) {} }
    }
}
