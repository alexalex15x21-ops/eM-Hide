package com.em.hide

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.media.MediaDataSource
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.io.RandomAccessFile
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** قراءة عشوائية من ملف مشفّر (AES-CBC) عشان الفيديو يتشغّل من غير ما نفك الملف كله */
class VaultDataSource(private val m: Vault.Meta, private val key: SecretKeySpec) : MediaDataSource() {
    private val raf = RandomAccessFile(m.file, "r")

    override fun getSize(): Long = m.size
    override fun close() { try { raf.close() } catch (_: Exception) {} }

    @Synchronized
    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        if (position >= m.size) return -1
        val n = minOf(size.toLong(), m.size - position, 1L shl 20).toInt()
        val p = m.hdr + position
        val bs = (p / 16) * 16
        val be = ((p + n + 15) / 16) * 16
        raf.seek(bs)
        val buf = ByteArray(16 + (be - bs).toInt())
        raf.readFully(buf)
        val c = Cipher.getInstance("AES/CBC/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(buf, 0, 16))
        val plain = c.doFinal(buf, 16, buf.size - 16)
        System.arraycopy(plain, (p - bs).toInt(), buffer, offset, n)
        return n
    }
}

/** صورة بتكبير بالقرصتين + دبل تاب. وبتسيب السحب الجانبي للصفحات (ViewPager2) لما الصورة مش مكبّرة أو على الحافة */
class ZoomImageView(ctx: Context) : ImageView(ctx) {
    var onTap: (() -> Unit)? = null
    private val mx = Matrix()
    private var scale = 1f
    private var lastX = 0f
    val isZoomed: Boolean get() = scale > 1.01f

    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (scale * d.scaleFactor).coerceIn(1f, 6f)
            val f = ns / scale
            mx.postScale(f, f, d.focusX, d.focusY)
            scale = ns
            fixBounds()
            imageMatrix = mx
            return true
        }
    })

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (isZoomed) reset() else {
                mx.postScale(2.5f, 2.5f, e.x, e.y); scale = 2.5f; fixBounds(); imageMatrix = mx
            }
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (isZoomed) { mx.postTranslate(-dx, -dy); fixBounds(); imageMatrix = mx }
            return true
        }
    })

    init { scaleType = ScaleType.MATRIX }

    override fun setImageBitmap(bm: Bitmap?) {
        super.setImageBitmap(bm)
        if (width > 0) reset()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (changed) reset()
    }

    private fun reset() {
        val d = drawable ?: return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0 || dh <= 0 || width == 0) return
        val s = minOf(width / dw, height / dh)
        mx.reset()
        mx.postScale(s, s)
        mx.postTranslate((width - dw * s) / 2, (height - dh * s) / 2)
        scale = 1f
        imageMatrix = mx
    }

    private fun bounds(): RectF {
        val d = drawable ?: return RectF()
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        mx.mapRect(r)
        return r
    }

    private fun fixBounds() {
        val r = bounds()
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2 - r.left
        else if (r.left > 0) dx = -r.left else if (r.right < width) dx = width - r.right
        if (r.height() <= height) dy = (height - r.height()) / 2 - r.top
        else if (r.top > 0) dy = -r.top else if (r.bottom < height) dy = height - r.bottom
        mx.postTranslate(dx, dy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                parent?.requestDisallowInterceptTouchEvent(isZoomed)
            }
            MotionEvent.ACTION_POINTER_DOWN -> parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_MOVE -> if (isZoomed && e.pointerCount == 1) {
                val dx = e.x - lastX
                lastX = e.x
                val r = bounds()
                val pass = (dx > 0 && r.left >= -1f) || (dx < 0 && r.right <= width + 1f)
                parent?.requestDisallowInterceptTouchEvent(!pass)
            }
        }
        sg.onTouchEvent(e)
        if (!sg.isInProgress) gd.onTouchEvent(e)
        return true
    }
}

/**
 * صفحة فيديو داخل العارض. بتعرض صورة مصغّرة فورًا (من غير شاشة سودا) وبتشغّل الفيديو
 * بس لما الصفحة تبقى هي الحالية (activate) وتوقفه لما تخرج منها (deactivate).
 */
class VideoPane(ctx: Context, private val m: Vault.Meta, poster: Bitmap?) :
    FrameLayout(ctx), TextureView.SurfaceTextureListener {

    private val pad = (10 * resources.displayMetrics.density).toInt()
    private val tv = TextureView(ctx)
    private val posterIv = ImageView(ctx)
    private val playBtn = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val timeTv = TextView(ctx)
    private val bar = LinearLayout(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private var surface: Surface? = null
    private var mp: MediaPlayer? = null
    private var ds: VaultDataSource? = null
    private var active = false
    private var prepared = false

    private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private val hidePoster = Runnable { posterIv.visibility = View.GONE }

    private val ticker = object : Runnable {
        override fun run() {
            val p = mp ?: return
            if (prepared) {
                try {
                    seek.progress = p.currentPosition
                    timeTv.text = fmt(p.currentPosition) + " / " + fmt(p.duration)
                } catch (_: Exception) {}
            }
            handler.postDelayed(this, 500)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        layoutDirection = LAYOUT_DIRECTION_LTR
        addView(tv, LayoutParams(-1, -1, Gravity.CENTER))
        tv.surfaceTextureListener = this

        posterIv.scaleType = ImageView.ScaleType.FIT_CENTER
        posterIv.setBackgroundColor(Color.BLACK)
        if (poster != null) posterIv.setImageBitmap(poster)
        addView(posterIv, LayoutParams(-1, -1))

        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0x99000000.toInt())
        bar.setPadding(pad, pad, pad, pad)
        bar.visibility = View.INVISIBLE

        playBtn.text = "▶"
        playBtn.textSize = 26f
        playBtn.setTextColor(Color.WHITE)
        playBtn.setPadding(pad, 0, pad, 0)
        playBtn.setOnClickListener { toggle() }

        timeTv.setTextColor(Color.WHITE)
        timeTv.textSize = 12f
        timeTv.text = "0:00"

        seek.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        // عشان سحب شريط الفيديو ما يقلبش الصفحة
        seek.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && prepared) try { mp?.seekTo(p) } catch (_: Exception) {}
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        bar.addView(playBtn)
        bar.addView(seek)
        bar.addView(timeTv)
        addView(bar, LayoutParams(-1, -2, Gravity.BOTTOM))
    }

    fun setPoster(b: Bitmap) { if (posterIv.visibility == View.VISIBLE) posterIv.setImageBitmap(b) }

    fun activate() {
        active = true
        bar.visibility = View.VISIBLE
        startIfReady()
    }

    fun deactivate() {
        active = false
        bar.visibility = View.INVISIBLE
        stopPlayer()
        posterIv.visibility = View.VISIBLE
        playBtn.text = "▶"
        seek.progress = 0
        timeTv.text = "0:00"
    }

    fun release() {
        active = false
        stopPlayer()
    }

    private fun toggle() {
        val p = mp ?: return
        if (!prepared) return
        try {
            if (p.isPlaying) { p.pause(); playBtn.text = "▶" } else { p.start(); playBtn.text = "⏸" }
        } catch (_: Exception) {}
    }

    private fun fit(w: Int, h: Int) {
        if (w == 0 || h == 0) return
        post {
            if (width == 0 || height == 0) return@post
            val s = minOf(width.toFloat() / w, height.toFloat() / h)
            tv.layoutParams = LayoutParams((w * s).toInt(), (h * s).toInt(), Gravity.CENTER)
        }
    }

    private fun startIfReady() {
        if (!active || mp != null) return
        val s = surface ?: return
        val k = Vault.key ?: return
        try {
            val d = VaultDataSource(m, k)
            ds = d
            mp = MediaPlayer().apply {
                setDataSource(d)
                setSurface(s)
                setOnVideoSizeChangedListener { _, w, h -> fit(w, h) }
                setOnPreparedListener {
                    prepared = true
                    seek.max = it.duration
                    it.start()
                    playBtn.text = "⏸"
                    handler.removeCallbacks(ticker)
                    handler.post(ticker)
                    handler.postDelayed(hidePoster, 700)
                }
                setOnInfoListener { _, what, _ ->
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) posterIv.visibility = View.GONE
                    false
                }
                setOnCompletionListener { playBtn.text = "▶" }
                setOnErrorListener { _, _, _ -> timeTv.text = "⚠"; true }
                prepareAsync()
            }
        } catch (e: Exception) {
            timeTv.text = "⚠"
        }
    }

    private fun stopPlayer() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(hidePoster)
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        prepared = false
        ds?.close()
        ds = null
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        startIfReady()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        stopPlayer()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    override fun onDetachedFromWindow() {
        stopPlayer()
        super.onDetachedFromWindow()
    }
}
