package com.em.hide

import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.media.MediaDataSource
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.io.RandomAccessFile
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** قراءة عشوائية من ملف مشفّر (AES-CBC) عشان الفيديو يتشغّل من غير ما نفك الملف كله */
class VaultDataSource(private val m: Vault.Meta, private val key: SecretKeySpec) : MediaDataSource() {
    private val raf = RandomAccessFile(m.file, "r")

    override fun getSize(): Long = m.size
    override fun close() { try { raf.close() } catch (_: Exception) {} }

    @Synchronized
    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        if (position >= m.size) return -1
        val n = minOf(size.toLong(), m.size - position, 1L shl 20).toInt()
        val p = m.hdr + position
        val bs = (p / 16) * 16
        val be = ((p + n + 15) / 16) * 16
        raf.seek(bs)
        val buf = ByteArray(16 + (be - bs).toInt())
        raf.readFully(buf)
        val c = Cipher.getInstance("AES/CBC/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(buf, 0, 16))
        val plain = c.doFinal(buf, 16, buf.size - 16)
        System.arraycopy(plain, (p - bs).toInt(), buffer, offset, n)
        return n
    }
}

class ZoomImageView(ctx: Context) : ImageView(ctx) {
    var onSwipe: ((Int) -> Unit)? = null
    var onTap: (() -> Unit)? = null
    private val mx = Matrix()
    private var scale = 1f

    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (scale * d.scaleFactor).coerceIn(1f, 6f)
            val f = ns / scale
            mx.postScale(f, f, d.focusX, d.focusY)
            scale = ns
            fixBounds()
            imageMatrix = mx
            return true
        }
    })

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scale > 1.01f) reset() else {
                mx.postScale(2.5f, 2.5f, e.x, e.y); scale = 2.5f; fixBounds(); imageMatrix = mx
            }
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (scale > 1.01f) { mx.postTranslate(-dx, -dy); fixBounds(); imageMatrix = mx }
            return true
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (scale <= 1.01f && Math.abs(vx) > 900 && Math.abs(vx) > Math.abs(vy)) {
                onSwipe?.invoke(if (vx < 0) 1 else -1)
            }
            return true
        }
    })

    init { scaleType = ScaleType.MATRIX }

    override fun setImageBitmap(bm: android.graphics.Bitmap?) {
        super.setImageBitmap(bm)
        if (width > 0) reset()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (changed) reset()
    }

    private fun reset() {
        val d = drawable ?: return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0 || dh <= 0 || width == 0) return
        val s = minOf(width / dw, height / dh)
        mx.reset()
        mx.postScale(s, s)
        mx.postTranslate((width - dw * s) / 2, (height - dh * s) / 2)
        scale = 1f
        imageMatrix = mx
    }

    private fun fixBounds() {
        val d = drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        mx.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2 - r.left
        else if (r.left > 0) dx = -r.left else if (r.right < width) dx = width - r.right
        if (r.height() <= height) dy = (height - r.height()) / 2 - r.top
        else if (r.top > 0) dy = -r.top else if (r.bottom < height) dy = height - r.bottom
        mx.postTranslate(dx, dy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sg.onTouchEvent(e)
        if (!sg.isInProgress) gd.onTouchEvent(e)
        return true
    }
}

class VideoPane(ctx: Context, private val m: Vault.Meta) : FrameLayout(ctx), SurfaceHolder.Callback {
    private val sv = SurfaceView(ctx)
    private var mp: MediaPlayer? = null
    private var ds: VaultDataSource? = null
    private val handler = Handler(Looper.getMainLooper())
    private val playBtn = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val timeTv = TextView(ctx)
    private var prepared = false

    private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private val ticker = object : Runnable {
        override fun run() {
            val p = mp ?: return
            if (prepared) {
                try {
                    seek.progress = p.currentPosition
                    timeTv.text = fmt(p.currentPosition) + " / " + fmt(p.duration)
                } catch (_: Exception) {}
            }
            handler.postDelayed(this, 500)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        layoutDirection = LAYOUT_DIRECTION_LTR
        addView(sv, LayoutParams(-1, -1, Gravity.CENTER))
        sv.holder.addCallback(this)

        val pad = (10 * resources.displayMetrics.density).toInt()
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(pad, pad, pad, pad)
        }
        playBtn.apply {
            text = "▶"; textSize = 26f; setTextColor(Color.WHITE); setPadding(pad, 0, pad, 0)
            setOnClickListener { toggle() }
        }
        timeTv.apply { setTextColor(Color.WHITE); textSize = 12f; text = "0:00" }
        seek.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && prepared) try { mp?.seekTo(p) } catch (_: Exception) {}
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        bar.addView(playBtn)
        bar.addView(seek)
        bar.addView(timeTv)
        addView(bar, LayoutParams(-1, -2, Gravity.BOTTOM))
    }

    private fun toggle() {
        val p = mp ?: return
        if (!prepared) return
        try {
            if (p.isPlaying) { p.pause(); playBtn.text = "▶" } else { p.start(); playBtn.text = "⏸" }
        } catch (_: Exception) {}
    }

    private fun fit(w: Int, h: Int) {
        if (w == 0 || h == 0) return
        post {
            val s = minOf(width.toFloat() / w, height.toFloat() / h)
            sv.layoutParams = LayoutParams((w * s).toInt(), (h * s).toInt(), Gravity.CENTER)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val k = Vault.key ?: return
        try {
            val d = VaultDataSource(m, k)
            ds = d
            mp = MediaPlayer().apply {
                setDataSource(d)
                setDisplay(holder)
                setOnVideoSizeChangedListener { _, w, h -> fit(w, h) }
                setOnPreparedListener {
                    prepared = true
                    seek.max = it.duration
                    it.start()
                    playBtn.text = "⏸"
                    handler.removeCallbacks(ticker)
                    handler.post(ticker)
                }
                setOnCompletionListener { playBtn.text = "▶" }
                setOnErrorListener { _, _, _ -> timeTv.text = "⚠"; true }
                prepareAsync()
            }
        } catch (e: Exception) {
            timeTv.text = "⚠"
        }
    }

    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) {}

    fun release() {
        handler.removeCallbacks(ticker)
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        ds?.close()
        ds = null
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }
}
