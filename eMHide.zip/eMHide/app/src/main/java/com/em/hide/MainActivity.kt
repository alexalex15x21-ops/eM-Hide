package com.em.hide

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.text.InputType
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import javax.crypto.Cipher

class MainActivity : Activity() {

    private val BG = 0xFF0F172A.toInt()
    private val CARD = 0xFF1E293B.toInt()
    private val GREEN = 0xFF16A34A.toInt()
    private val BLUE = 0xFF2563EB.toInt()
    private val RED = 0xFFDC2626.toInt()
    private val GRAY = 0xFF334155.toInt()
    private val MUTED = 0xFF94A3B8.toInt()
    private val REQ_PICK = 101
    private val REQ_DELETE = 102

    private var items: List<Vault.Meta> = emptyList()
    private var busy = false
    private var screen = 0 // 0 دخول، 1 رئيسية، 2 فولدر، 3 عارض
    private var curCat = 0
    private var catItems: List<Vault.Meta> = emptyList()
    private var trashItems: List<Vault.Meta> = emptyList()
    private val selected = LinkedHashSet<String>()

    private val countViews = arrayOfNulls<TextView>(4)
    private var folderAdapter: BaseAdapter? = null
    private var folderRoot: View? = null
    private var selBtn: Button? = null
    private var folderList: AbsListView? = null
    private var savedPos = 0
    private var savedTop = 0
    private var folderTitle: TextView? = null
    private var emptyTv: TextView? = null
    private var barBox: LinearLayout? = null

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val durs = ConcurrentHashMap<String, Long>()
    private val pool = Executors.newFixedThreadPool(3)
    private val pool2 = Executors.newFixedThreadPool(2)
    private val fullCache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private var vList: List<Vault.Meta> = emptyList()
    private var vIdx = 0
    private var vPager: ViewPager2? = null
    private var vTitle: TextView? = null
    private var vCount: TextView? = null
    private var vBars: List<View> = emptyList()
    private var bioShowing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        File(cacheDir, "open").deleteRecursively()
        if (Vault.key != null) showHome() else showLogin(true)
    }

    override fun onResume() {
        super.onResume()
        busy = false
        if (screen == 0 && !bioShowing && Vault.key == null && Vault.isSetup(this) &&
            Bio.enabled(this) && Bio.mode(this) != 0
        ) loginBio()
    }

    override fun onStop() {
        super.onStop()
        if (!busy && Vault.key != null) lock()
    }

    override fun onBackPressed() {
        when (screen) {
            3 -> { closeViewer(); showFolder(curCat, true) }
            2 -> if (selected.isNotEmpty()) {
                selected.clear(); folderAdapter?.notifyDataSetChanged(); updateBar()
            } else showHome()
            else -> super.onBackPressed()
        }
    }

    private fun lock() {
        closeViewer()
        folderRoot = null
        folderList = null
        Vault.key = null
        cache.evictAll()
        fullCache.evictAll()
        selected.clear()
        items = emptyList()
        File(cacheDir, "open").deleteRecursively()
        showLogin()
    }

    // ---------------- أدوات الواجهة ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(BG)
        setPadding(dp(16), dp(36), dp(16), dp(12))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        layoutParams = ViewGroup.LayoutParams(-1, -1)
    }

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun field(h: String) = EditText(this).apply {
        hint = h
        setHintTextColor(MUTED)
        setTextColor(Color.WHITE)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    }

    private fun btn(t: String, color: Int, full: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 14f
        background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(color) }
        layoutParams = (if (full) LinearLayout.LayoutParams(-1, -2) else LinearLayout.LayoutParams(0, -2, 1f))
            .apply { setMargins(dp(4), dp(6), dp(4), dp(2)) }
        setOnClickListener { onClick() }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun icon(mime: String) = when {
        mime.startsWith("image/") -> "🖼"
        mime.startsWith("video/") -> "🎬"
        mime.startsWith("audio/") -> "🎵"
        else -> "📄"
    }

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.1f GB".format(b / 1073741824.0)
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1024 -> "${b / 1024} KB"
        else -> "$b B"
    }

    private fun fmtDur(ms: Long): String {
        if (ms < 0) return ""
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun work(msg: String, job: () -> Unit, done: () -> Unit = {}) {
        val d = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
        Thread {
            try { job() } catch (e: Exception) { runOnUiThread { toast("خطأ: ${e.message}") } }
            runOnUiThread { d.dismiss(); done() }
        }.start()
    }

    private fun itemsFor(cat: Int) = if (cat == 3) trashItems else items.filter { it.cat == cat }

    private fun workP(title: String, job: (ProgressDlg) -> Unit, done: () -> Unit = {}) {
        val d = ProgressDlg(this, title)
        Thread {
            try { job(d) } catch (e: Exception) { runOnUiThread { toast("خطأ: ${e.message}") } }
            runOnUiThread { d.dismiss(); done() }
        }.start()
    }

    private fun reload(then: () -> Unit) {
        Thread {
            try { Vault.purgeOld(this) } catch (_: Exception) {}
            val l = try { Vault.list(this) } catch (_: Exception) { emptyList() }
            val t = try { Vault.list(this, true) } catch (_: Exception) { emptyList() }
            runOnUiThread { items = l; trashItems = t; then() }
        }.start()
    }

    private fun refreshCurrent() {
        selected.clear()
        reload { if (screen == 2) refreshFolder() else if (screen == 1) updateCounts() }
    }

    // ---------------- الدخول ----------------

    private fun showLogin(autoBio: Boolean = false) {
        screen = 0
        val setup = !Vault.isSetup(this)
        val r = root()
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(label("🔒", 56f).apply { gravity = Gravity.CENTER })
        r.addView(label("eM Hide", 30f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        r.addView(
            label(
                if (setup) "أنشئ كلمة سر لحماية ملفاتك\n(لو نسيتها مفيش طريقة لاسترجاع الملفات)" else "أدخل كلمة السر",
                14f, MUTED
            ).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) }
        )
        val pw = field("كلمة السر")
        r.addView(pw)
        val pw2 = if (setup) field("تأكيد كلمة السر").also { r.addView(it) } else null
        r.addView(btn(if (setup) "إنشاء وفتح" else "فتح", GREEN, true) {
            val p = pw.text.toString()
            if (setup) {
                when {
                    p.length < 4 -> toast("كلمة السر لازم تكون 4 حروف أو أرقام على الأقل")
                    p != pw2!!.text.toString() -> toast("كلمتا السر غير متطابقتين")
                    else -> { Vault.setup(this, p); showHome() }
                }
            } else {
                if (Vault.login(this, p)) showHome() else toast("كلمة السر غير صحيحة")
            }
        }.apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20) })
        val bioOn = !setup && Bio.enabled(this) && Bio.mode(this) != 0
        if (bioOn) r.addView(btn("👆 فتح بالبصمة", BLUE, true) { loginBio() })
        setContentView(r)
    }

    // ---------------- البصمة ----------------

    private fun bioPrompt(title: String, cipher: Cipher, strong: Boolean, onOk: (Cipher) -> Unit) {
        busy = true
        bioShowing = true
        val b = BiometricPrompt.Builder(this)
            .setTitle(title)
            .setNegativeButton("إلغاء", mainExecutor) { _, _ -> busy = false; bioShowing = false }
        if (!strong && Build.VERSION.SDK_INT >= 30) {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        }
        val p = b.build()
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                busy = false
                bioShowing = false
                if (strong) r.cryptoObject?.cipher?.let(onOk) else onOk(cipher)
            }

            override fun onAuthenticationError(code: Int, msg: CharSequence?) {
                busy = false
                bioShowing = false
                if (code != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED &&
                    code != BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                ) toast(msg.toString())
            }
        }
        if (strong) p.authenticate(BiometricPrompt.CryptoObject(cipher), CancellationSignal(), mainExecutor, cb)
        else p.authenticate(CancellationSignal(), mainExecutor, cb)
    }

    private fun enableBio() {
        val mode = Bio.mode(this)
        if (mode == 0) return toast(Bio.reason(this))
        val strong = mode == 1
        try {
            val c = Bio.encCipher(strong)
            bioPrompt("تفعيل البصمة", c, strong) { ci ->
                try {
                    Bio.save(this, ci, Vault.keyBytes(), strong)
                    toast("تم تفعيل البصمة ✅")
                    showHome()
                } catch (e: Exception) { toast("فشل التفعيل: ${e.message}") }
            }
        } catch (e: Exception) {
            toast("فشل التفعيل: ${e.message}\n(تأكد إن موبايلك عليه قفل شاشة PIN أو نمط)")
        }
    }

    private fun loginBio() {
        try {
            val strong = Bio.isStrong(this)
            val c = Bio.decCipher(this)
            bioPrompt("فتح eM Hide", c, strong) { ci ->
                try {
                    Vault.unlockWith(Bio.load(this, ci))
                    showHome()
                } catch (e: Exception) { toast("فشلت البصمة — استخدم كلمة السر") }
            }
        } catch (e: KeyPermanentlyInvalidatedException) {
            Bio.disable(this)
            toast("البصمات المسجّلة اتغيّرت — ادخل بكلمة السر وفعّل البصمة من جديد")
            showLogin()
        } catch (e: Exception) {
            toast("البصمة غير متاحة — استخدم كلمة السر")
        }
    }

    // ---------------- الرئيسية (3 فولدرات) ----------------

    private val catNames = listOf("الصور", "الفيديوهات", "الملفات", "سلة المحذوفات (Recycle bin)")
    private val catIcons = listOf("🖼", "🎬", "📁", "🗑")

    private fun showHome() {
        screen = 1
        folderRoot = null
        folderList = null
        selected.clear()
        val r = root()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("🔒 eM Hide", 24f, Color.WHITE, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        head.addView(btn("قفل", GRAY) { lock() }.apply { layoutParams = LinearLayout.LayoutParams(dp(80), -2) })
        r.addView(head)

        for (i in 0..3) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(20), dp(18), dp(20))
                background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(CARD) }
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
                setOnClickListener { showFolder(i) }
            }
            card.addView(label(catIcons[i], 36f).apply { setPadding(0, 0, dp(16), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            col.addView(label(catNames[i], 19f, Color.WHITE, true))
            val cnt = label("...", 13f, MUTED)
            countViews[i] = cnt
            col.addView(cnt)
            card.addView(col)
            card.addView(label("‹", 28f, MUTED))
            r.addView(card)
        }

        r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) })
        val bioOn = Bio.enabled(this)
        r.addView(btn(if (bioOn) "👆 إيقاف فتح التطبيق بالبصمة" else "👆 تفعيل فتح التطبيق بالبصمة", GRAY, true) {
            if (bioOn) { Bio.disable(this); toast("تم إيقاف البصمة"); showHome() } else enableBio()
        })
        r.addView(btn("➕ إخفاء ملفات", GREEN, true) { pickFiles() })
        setContentView(r)
        reload { updateCounts() }
    }

    private fun updateCounts() {
        for (i in 0..2) countViews[i]?.text = "${items.count { it.cat == i }} عنصر"
        countViews[3]?.text = "${trashItems.size} عنصر • بتتحذف تلقائيًا بعد ${Vault.TRASH_DAYS} يوم"
    }

    // ---------------- الفولدر ----------------

    private inner class Cell(c: Context) : FrameLayout(c) {
        val iv = ImageView(c).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(CARD)
        }
        val badge = TextView(c).apply {
            setTextColor(Color.WHITE); textSize = 11f
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(5), dp(1), dp(5), dp(1))
        }
        val dim = View(c).apply { setBackgroundColor(0x663B82F6); visibility = View.GONE }
        val chk = TextView(c).apply {
            text = "✓"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BLUE); setStroke(dp(2), Color.WHITE) }
            visibility = View.GONE
        }

        init {
            addView(iv, LayoutParams(-1, -1))
            addView(dim, LayoutParams(-1, -1))
            addView(badge, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))
            addView(chk, LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.START).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
        }

        override fun onMeasure(w: Int, h: Int) = super.onMeasure(w, w)

        fun bind(m: Vault.Meta) {
            val path = m.file.path
            iv.tag = path
            val b = cache.get(path)
            if (b != null) iv.setImageBitmap(b) else { iv.setImageDrawable(null); loadThumb(m, this) }
            badge.visibility = if (m.cat == 1) View.VISIBLE else View.GONE
            badge.text = "▶ " + fmtDur(durs[path] ?: -1L)
            val s = selected.contains(path)
            dim.visibility = if (s) View.VISIBLE else View.GONE
            chk.visibility = if (s) View.VISIBLE else View.GONE
        }

        fun setThumb(b: Bitmap, dur: Long) {
            iv.setImageBitmap(b)
            if (dur >= 0) badge.text = "▶ " + fmtDur(dur)
        }
    }

    private fun loadThumb(m: Vault.Meta, cell: Cell) {
        val path = m.file.path
        pool.execute {
            val t = try { Vault.loadThumb(m) ?: Vault.generateThumb(m) } catch (_: Exception) { null }
            if (t != null) {
                cache.put(path, t.bmp)
                durs[path] = t.dur
                runOnUiThread { if (cell.iv.tag == path) cell.setThumb(t.bmp, t.dur) }
            }
        }
    }

    private inner class GridAdapter : BaseAdapter() {
        override fun getCount() = catItems.size
        override fun getItem(i: Int): Any = catItems[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, cv: View?, p: ViewGroup?): View {
            val cell = (cv as? Cell) ?: Cell(this@MainActivity)
            cell.bind(catItems[i])
            return cell
        }
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = catItems.size
        override fun getItem(i: Int): Any = catItems[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, cv: View?, p: ViewGroup?): View {
            val m = catItems[i]
            return TextView(this@MainActivity).apply {
                text = (if (selected.contains(m.file.path)) "✅ " else icon(m.mime) + " ") + m.name + "\n" + fmt(m.size) +
                    (if (curCat == 3) "  •  متبقي ${Vault.daysLeft(m)} يوم" else "")
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding(dp(12), dp(14), dp(12), dp(14))
                setBackgroundColor(if (selected.contains(m.file.path)) 0x553B82F6 else 0)
            }
        }
    }

    private fun restoreScroll() {
        val av = folderList ?: return
        av.post {
            av.setSelectionFromTop(savedPos, savedTop)
            av.post {
                if (vIdx in catItems.indices && (vIdx < av.firstVisiblePosition || vIdx > av.lastVisiblePosition)) {
                    av.setSelectionFromTop(vIdx, dp(140))
                }
            }
        }
    }

    private fun showFolder(cat: Int, reuse: Boolean = false) {
        val fr = folderRoot
        if (reuse && fr != null && folderList != null && curCat == cat) {
            screen = 2
            setContentView(fr)
            refreshFolder()
            reload { refreshFolder() }
            restoreScroll()
            return
        }
        screen = 2
        curCat = cat
        selected.clear()
        catItems = itemsFor(cat)
        val r = root()
        r.setPadding(dp(8), dp(36), dp(8), dp(8))

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(btn("→", GRAY) { onBackPressed() }.apply { layoutParams = LinearLayout.LayoutParams(dp(56), -2) })
        val title = label("", 17f, Color.WHITE, true).apply {
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        folderTitle = title
        head.addView(title)
        val sb = btn("☑ تحديد الكل", BLUE) { toggleAll() }.apply {
            layoutParams = LinearLayout.LayoutParams(-2, -2)
            visibility = View.GONE
        }
        selBtn = sb
        head.addView(sb)
        r.addView(head)

        val box = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val av: AbsListView
        if (cat < 2) {
            val a = GridAdapter()
            folderAdapter = a
            av = GridView(this).apply {
                numColumns = 3
                horizontalSpacing = dp(2)
                verticalSpacing = dp(2)
                setSelector(ColorDrawable(0))
                adapter = a
            }
        } else {
            val a = FileAdapter()
            folderAdapter = a
            av = ListView(this).apply {
                divider = ColorDrawable(0x22FFFFFF)
                dividerHeight = 1
                setSelector(ColorDrawable(0))
                adapter = a
            }
        }
        folderList = av
        av.setOnItemClickListener { _, _, pos, _ -> onItem(pos) }
        av.setOnItemLongClickListener { _, _, pos, _ -> toggle(pos); true }
        box.addView(av, FrameLayout.LayoutParams(-1, -1))
        val et = label("الفولدر فاضي", 15f, MUTED).apply { gravity = Gravity.CENTER }
        emptyTv = et
        box.addView(et, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        r.addView(box)

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        barBox = bar
        r.addView(bar)
        folderRoot = r
        setContentView(r)
        refreshFolder()
        reload { refreshFolder() }
    }

    private fun refreshFolder() {
        catItems = itemsFor(curCat)
        val paths = catItems.map { it.file.path }.toSet()
        selected.retainAll(paths)
        folderAdapter?.notifyDataSetChanged()
        folderTitle?.text = "${catIcons[curCat]} ${catNames[curCat]} (${catItems.size})"
        emptyTv?.text = if (curCat == 3) "سلة المحذوفات فاضية" else "الفولدر فاضي"
        emptyTv?.visibility = if (catItems.isEmpty()) View.VISIBLE else View.GONE
        updateBar()
    }

    private fun updateBar() {
        val b = barBox ?: return
        b.removeAllViews()
        b.visibility = if (selected.isEmpty() && (curCat != 3 || catItems.isEmpty())) View.GONE else View.VISIBLE
        selBtn?.let { sbn ->
            sbn.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
            val all = catItems.isNotEmpty() && selected.size == catItems.size
            sbn.text = if (all) "☐ إلغاء تحديد الكل" else "☑ تحديد الكل"
        }
        if (curCat == 3) {
            if (selected.isEmpty()) {
                if (catItems.isNotEmpty()) b.addView(btn("🧹 تفريغ السلة", RED, true) { confirmDeleteForever(catItems) })
            } else {
                b.addView(btn("↩ استرجاع (${selected.size})", BLUE) { restoreFromTrash(selectedMetas()) })
                b.addView(btn("🗑 حذف نهائي", RED) { confirmDeleteForever(selectedMetas()) })
                b.addView(btn("✖", GRAY) { selected.clear(); folderAdapter?.notifyDataSetChanged(); updateBar() })
            }
            return
        }
        if (selected.isNotEmpty()) {
            b.addView(btn("↩ إلغاء الإخفاء (${selected.size})", BLUE) { restore(selectedMetas()) })
            b.addView(btn("🗑 حذف", RED) { confirmDelete(selectedMetas()) })
            b.addView(btn("✖", GRAY) { selected.clear(); folderAdapter?.notifyDataSetChanged(); updateBar() })
        }
    }

    private fun toggleAll() {
        val all = catItems.isNotEmpty() && selected.size == catItems.size
        selected.clear()
        if (!all) catItems.forEach { selected.add(it.file.path) }
        folderAdapter?.notifyDataSetChanged()
        updateBar()
    }

    private fun selectedMetas() = catItems.filter { selected.contains(it.file.path) }

    private fun toggle(pos: Int) {
        val p = catItems.getOrNull(pos)?.file?.path ?: return
        if (!selected.remove(p)) selected.add(p)
        folderAdapter?.notifyDataSetChanged()
        updateBar()
    }

    private fun onItem(pos: Int) {
        if (selected.isNotEmpty()) return toggle(pos)
        val m = catItems.getOrNull(pos) ?: return
        if (curCat == 3) return toggle(pos)
        if (m.cat < 2) showViewer(catItems, pos) else openExternal(m)
    }

    // ---------------- عارض الصور والفيديو (صفحات بسحب جانبي مباشر) ----------------

    private inner class Page(val frame: FrameLayout) : RecyclerView.ViewHolder(frame) {
        var video: VideoPane? = null
        var token = 0
    }

    private inner class PagerAdapter : RecyclerView.Adapter<Page>() {
        override fun getItemCount() = vList.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Page {
            val f = FrameLayout(this@MainActivity).apply {
                layoutParams = ViewGroup.LayoutParams(-1, -1)
                setBackgroundColor(Color.BLACK)
            }
            return Page(f)
        }

        override fun onBindViewHolder(h: Page, pos: Int) {
            h.video?.release()
            h.video = null
            h.frame.removeAllViews()
            val tk = ++h.token
            val m = vList[pos]
            val path = m.file.path
            if (m.cat == 1) {
                val v = VideoPane(this@MainActivity, m, cache.get(path))
                h.video = v
                h.frame.addView(v, FrameLayout.LayoutParams(-1, -1))
                if (vPager?.currentItem == pos) v.activate()
                if (cache.get(path) == null) {
                    pool2.execute {
                        val t = try { Vault.loadThumb(m) ?: Vault.generateThumb(m) } catch (_: Exception) { null }
                        if (t != null) {
                            cache.put(path, t.bmp)
                            runOnUiThread { if (h.token == tk) v.setPoster(t.bmp) }
                        }
                    }
                }
            } else {
                val z = ZoomImageView(this@MainActivity).apply {
                    onTap = { vBars.forEach { it.visibility = if (it.visibility == View.VISIBLE) View.GONE else View.VISIBLE } }
                }
                h.frame.addView(z, FrameLayout.LayoutParams(-1, -1))
                val full = fullCache.get(path)
                if (full != null) {
                    z.setImageBitmap(full)
                } else {
                    cache.get(path)?.let { z.setImageBitmap(it) }   // صورة مصغّرة فورًا بدل الشاشة السودا
                    pool2.execute {
                        if (cache.get(path) == null) {
                            val t = try { Vault.loadThumb(m) } catch (_: Exception) { null }
                            if (t != null) {
                                cache.put(path, t.bmp)
                                runOnUiThread { if (h.token == tk && fullCache.get(path) == null) z.setImageBitmap(t.bmp) }
                            }
                        }
                        val b = try { Vault.loadFull(m) } catch (_: Exception) { null }
                        if (b != null) {
                            fullCache.put(path, b)
                            runOnUiThread { if (h.token == tk) z.setImageBitmap(b) }
                        } else {
                            runOnUiThread { if (h.token == tk) toast("تعذّر عرض الصورة") }
                        }
                    }
                }
            }
        }

        override fun onViewRecycled(h: Page) {
            h.video?.release()
            h.video = null
            h.token++
        }
    }

    private fun onPage(position: Int) {
        if (position !in vList.indices) return
        vIdx = position
        vTitle?.text = vList[position].name
        vCount?.text = "${position + 1}/${vList.size}"
        val rv = vPager?.getChildAt(0) as? RecyclerView ?: return
        for (i in 0 until rv.childCount) {
            val h = rv.getChildViewHolder(rv.getChildAt(i)) as? Page ?: continue
            val v = h.video ?: continue
            @Suppress("DEPRECATION")
            if (h.adapterPosition == position) v.activate() else v.deactivate()
        }
    }

    private fun showViewer(list: List<Vault.Meta>, idx: Int) {
        folderList?.let {
            savedPos = it.firstVisiblePosition
            savedTop = it.getChildAt(0)?.top ?: 0
        }
        screen = 3
        vList = list
        vIdx = idx
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF111827.toInt())
            setPadding(dp(6), dp(30), dp(6), dp(4))
        }
        top.addView(btn("←", GRAY) { onBackPressed() }.apply { layoutParams = LinearLayout.LayoutParams(dp(52), -2) })
        val title = label("", 14f).apply {
            maxLines = 1
            setPadding(dp(8), 0, dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        vTitle = title
        top.addView(title)
        val cnt = label("", 13f, MUTED)
        vCount = cnt
        top.addView(cnt)

        val pg = ViewPager2(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            offscreenPageLimit = 1
            adapter = PagerAdapter()
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) { onPage(position) }
            })
        }
        vPager = pg
        pg.setCurrentItem(idx, false)
        vBars = listOf(top)
        r.addView(top)
        r.addView(pg)
        setContentView(r)
        title.text = list[idx].name
        cnt.text = "${idx + 1}/${list.size}"
    }

    private fun closeViewer() {
        val rv = vPager?.getChildAt(0) as? RecyclerView
        if (rv != null) {
            for (i in 0 until rv.childCount) {
                (rv.getChildViewHolder(rv.getChildAt(i)) as? Page)?.video?.release()
            }
        }
        vPager?.adapter = null
        vPager = null
    }

    // ---------------- إخفاء ----------------

    private fun pickFiles() {
        busy = true
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_PICK)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_PICK -> if (res == RESULT_OK && data != null) {
                val uris = ArrayList<Uri>()
                data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
                if (uris.isEmpty()) data.data?.let { uris.add(it) }
                if (Vault.key != null) hide(uris)
            }
            REQ_DELETE -> toast(
                if (res == RESULT_OK) "تم حذف النسخ الأصلية من المعرض ✅"
                else "النسخ الأصلية لسه موجودة في المعرض — احذفها يدويًا"
            )
        }
    }

    private fun info(u: Uri): Triple<String, Long, String> {
        var name: String? = null
        var size = 0L
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0) name = c.getString(n)
                if (s >= 0) size = c.getLong(s)
            }
        }
        val mime = contentResolver.getType(u) ?: "application/octet-stream"
        return Triple(name ?: "file_${System.currentTimeMillis()}", size, mime)
    }

    private fun tryDelete(u: Uri): Boolean {
        try { if (DocumentsContract.deleteDocument(contentResolver, u)) return true } catch (_: Exception) {}
        try { if (contentResolver.delete(u, null, null) > 0) return true } catch (_: Exception) {}
        return false
    }

    private fun toMediaUri(u: Uri): Uri? {
        if (u.authority != "com.android.providers.media.documents") return null
        return try {
            val p = DocumentsContract.getDocumentId(u).split(":")
            if (p.size != 2) return null
            val base = when (p[0]) {
                "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else -> null
            }
            base?.let { ContentUris.withAppendedId(it, p[1].toLong()) }
        } catch (_: Exception) { null }
    }

    private fun hide(uris: List<Uri>) {
        var ok = 0
        var fail = 0
        var manual = 0
        val toDel = ArrayList<Uri>()
        workP("جاري التشفير والإخفاء", { d ->
            val infos = uris.map { try { info(it) } catch (e: Exception) { Triple("file", 0L, "application/octet-stream") } }
            val total = infos.sumOf { maxOf(it.second, 1L) }
            var base = 0L
            for ((idx, u) in uris.withIndex()) {
                val (name, size, mime) = infos[idx]
                val label = "${idx + 1}/${uris.size} • $name"
                d.update(base, total, label)
                try {
                    val emh = contentResolver.openInputStream(u)!!.use {
                        Vault.encrypt(this, it, name, mime, size, onProgress = { c -> d.update(base + c, total, label) })
                    }
                    ok++
                    try { Vault.makeThumbFromUri(this, u, mime, emh) } catch (_: Exception) {}
                    if (!tryDelete(u)) {
                        val mu = toMediaUri(u)
                        if (mu != null) toDel.add(mu) else manual++
                    }
                } catch (e: Exception) { fail++ }
                base += maxOf(size, 1L)
            }
            d.update(total, total, "تم")
        }, {
            refreshCurrent()
            var msg = "تم إخفاء $ok ملف"
            if (fail > 0) msg += " — فشل $fail"
            if (manual > 0) msg += " — $manual ملف لازم تحذف الأصل منه يدويًا"
            toast(msg)
            if (toDel.isNotEmpty()) askDelete(toDel)
        })
    }

    private fun askDelete(uris: List<Uri>) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                busy = true
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } catch (e: Exception) {
                toast("احذف النسخ الأصلية من المعرض يدويًا")
            }
        } else {
            var n = 0
            for (u in uris) try { if (contentResolver.delete(u, null, null) > 0) n++ } catch (_: Exception) {}
            if (n < uris.size) toast("احذف النسخ الأصلية من المعرض يدويًا")
        }
    }

    // ---------------- إلغاء الإخفاء / حذف / فتح ----------------

    private fun restore(sel: List<Vault.Meta>) {
        if (sel.isEmpty()) return toast("حدّد ملف واحد على الأقل")
        var ok = 0
        var fail = 0
        workP("جاري إلغاء التشفير والاسترجاع", { d ->
            val total = sel.sumOf { maxOf(it.size, 1L) }
            var base = 0L
            for ((idx, m) in sel.withIndex()) {
                val label = "${idx + 1}/${sel.size} • ${m.name}"
                d.update(base, total, label)
                try {
                    if (Vault.restore(this, m) { c -> d.update(base + c, total, label) }) {
                        ok++; cache.remove(m.file.path)
                    } else fail++
                } catch (e: Exception) { fail++ }
                base += maxOf(m.size, 1L)
            }
            d.update(total, total, "تم")
        }, {
            refreshCurrent()
            toast("تم إرجاع $ok ملف إلى فولدر \"${Vault.FOLDER}\" (جوه Pictures / Movies / Music / Download)" + if (fail > 0) " — فشل $fail" else "")
        })
    }

    /** حذف = نقل لسلة المحذوفات (30 يوم) */
    private fun confirmDelete(sel: List<Vault.Meta>, after: () -> Unit = {}) {
        if (sel.isEmpty()) return toast("حدّد ملف واحد على الأقل")
        AlertDialog.Builder(this)
            .setMessage("نقل ${sel.size} ملف لسلة المحذوفات؟\nهتفضل ${Vault.TRASH_DAYS} يوم وتقدر ترجعها.")
            .setPositiveButton("نقل") { _, _ ->
                after()
                work("جاري النقل...", {
                    sel.forEach { Vault.trash(this, it); cache.remove(it.file.path) }
                }, { refreshCurrent(); toast("تم النقل لسلة المحذوفات 🗑") })
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun confirmDeleteForever(sel: List<Vault.Meta>) {
        if (sel.isEmpty()) return
        AlertDialog.Builder(this)
            .setMessage("حذف ${sel.size} ملف نهائيًا؟ مش هتقدر ترجعهم.")
            .setPositiveButton("حذف نهائي") { _, _ ->
                sel.forEach { Vault.deleteForever(it) }
                refreshCurrent()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun restoreFromTrash(sel: List<Vault.Meta>) {
        if (sel.isEmpty()) return toast("حدّد ملف واحد على الأقل")
        work("جاري الاسترجاع...", {
            sel.forEach { Vault.restoreFromTrash(this, it) }
        }, { refreshCurrent(); toast("تم استرجاع ${sel.size} ملف للخزنة ✅") })
    }

    private fun openExternal(m: Vault.Meta) {
        var out: File? = null
        work("جاري الفتح...", {
            val dir = File(cacheDir, "open").apply { mkdirs() }
            val f = File(dir, m.name.replace("/", "_"))
            Vault.open(m.file).stream.use { ins -> f.outputStream().use { ins.copyTo(it) } }
            out = f
        }, {
            out?.let { f ->
                try {
                    val uri = FileProvider.getUriForFile(this, "$packageName.provider", f)
                    busy = true
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, m.mime)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                } catch (e: Exception) {
                    busy = false
                    toast("مفيش تطبيق يقدر يفتح الملف ده")
                }
            }
        })
    }
}
