package com.em.hide

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.security.keystore.KeyPermanentlyInvalidatedException
import javax.crypto.Cipher
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    private val BG = 0xFF0F172A.toInt()
    private val GREEN = 0xFF16A34A.toInt()
    private val BLUE = 0xFF2563EB.toInt()
    private val RED = 0xFFDC2626.toInt()
    private val GRAY = 0xFF334155.toInt()
    private val REQ_PICK = 101
    private val REQ_DELETE = 102

    private var items: List<Vault.Meta> = emptyList()
    private var busy = false
    private lateinit var list: ListView
    private lateinit var countTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        File(cacheDir, "open").deleteRecursively()
        if (Vault.key != null) showVault() else showLogin(true)
    }

    override fun onResume() {
        super.onResume()
        busy = false
    }

    override fun onStop() {
        super.onStop()
        if (!busy && Vault.key != null) lock()
    }

    private fun lock() {
        Vault.key = null
        File(cacheDir, "open").deleteRecursively()
        showLogin()
    }

    // ---------------- واجهة ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(BG)
        setPadding(dp(20), dp(40), dp(20), dp(20))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        layoutParams = ViewGroup.LayoutParams(-1, -1)
    }

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun field(h: String) = EditText(this).apply {
        hint = h
        setHintTextColor(0xFF94A3B8.toInt())
        setTextColor(Color.WHITE)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    }

    private fun btn(t: String, color: Int, full: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 14f
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(color)
        }
        layoutParams = (if (full) LinearLayout.LayoutParams(-1, -2) else LinearLayout.LayoutParams(0, -2, 1f))
            .apply { setMargins(dp(4), dp(6), dp(4), dp(2)) }
        setOnClickListener { onClick() }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun showLogin(autoBio: Boolean = false) {
        val setup = !Vault.isSetup(this)
        val r = root()
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(label("🔒", 56f).apply { gravity = Gravity.CENTER })
        r.addView(label("eM Hide", 30f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        r.addView(
            label(
                if (setup) "أنشئ كلمة سر لحماية ملفاتك\n(لو نسيتها مفيش طريقة لاسترجاع الملفات)" else "أدخل كلمة السر",
                14f, 0xFF94A3B8.toInt()
            ).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) }
        )
        val pw = field("كلمة السر")
        r.addView(pw)
        val pw2 = if (setup) field("تأكيد كلمة السر").also { r.addView(it) } else null
        r.addView(btn(if (setup) "إنشاء وفتح" else "فتح", GREEN, true) {
            val p = pw.text.toString()
            if (setup) {
                when {
                    p.length < 4 -> toast("كلمة السر لازم تكون 4 حروف أو أرقام على الأقل")
                    p != pw2!!.text.toString() -> toast("كلمتا السر غير متطابقتين")
                    else -> { Vault.setup(this, p); showVault() }
                }
            } else {
                if (Vault.login(this, p)) showVault() else toast("كلمة السر غير صحيحة")
            }
        }.apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20) })
        val bioOn = !setup && Bio.enabled(this) && Bio.available(this)
        if (bioOn) r.addView(btn("👆 فتح بالبصمة", BLUE, true) { loginBio() })
        setContentView(r)
        if (bioOn && autoBio) loginBio()
    }

    // ---------------- البصمة ----------------

    private fun bioPrompt(title: String, cipher: Cipher, onOk: (Cipher) -> Unit) {
        busy = true
        val p = BiometricPrompt.Builder(this)
            .setTitle(title)
            .setNegativeButton("إلغاء", mainExecutor) { _, _ -> busy = false }
            .build()
        p.authenticate(
            BiometricPrompt.CryptoObject(cipher), CancellationSignal(), mainExecutor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                    busy = false
                    r.cryptoObject?.cipher?.let(onOk)
                }

                override fun onAuthenticationError(code: Int, msg: CharSequence?) {
                    busy = false
                    if (code != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED &&
                        code != BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                    ) toast(msg.toString())
                }
            })
    }

    private fun enableBio() {
        if (!Bio.available(this)) return toast("لازم تسجّل بصمة في إعدادات الموبايل الأول")
        try {
            val c = Bio.encCipher()
            bioPrompt("تفعيل البصمة", c) { ci ->
                try {
                    Bio.save(this, ci, Vault.keyBytes())
                    toast("تم تفعيل البصمة ✅")
                    showVault()
                } catch (e: Exception) { toast("فشل التفعيل: ${e.message}") }
            }
        } catch (e: Exception) { toast("فشل التفعيل: ${e.message}") }
    }

    private fun loginBio() {
        try {
            val c = Bio.decCipher(this)
            bioPrompt("فتح eM Hide", c) { ci ->
                try {
                    Vault.unlockWith(Bio.load(this, ci))
                    showVault()
                } catch (e: Exception) { toast("فشلت البصمة — استخدم كلمة السر") }
            }
        } catch (e: KeyPermanentlyInvalidatedException) {
            Bio.disable(this)
            toast("البصمات المسجّلة اتغيّرت — ادخل بكلمة السر وفعّل البصمة من جديد")
            showLogin()
        } catch (e: Exception) {
            toast("البصمة غير متاحة — استخدم كلمة السر")
        }
    }

    private fun showVault() {
        val r = root()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("🔒 eM Hide", 24f, Color.WHITE, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        head.addView(btn("قفل", GRAY) { lock() }.apply { layoutParams = LinearLayout.LayoutParams(dp(80), -2) })
        r.addView(head)

        countTv = label("", 13f, 0xFF94A3B8.toInt()).apply { setPadding(0, dp(8), 0, dp(8)) }
        r.addView(countTv)

        list = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            emptyView = null
        }
        r.addView(list)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(btn("➕ إخفاء ملفات", GREEN) { pickFiles() })
        row1.addView(btn("↩ إلغاء الإخفاء", BLUE) { restoreSelected() })
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(btn("👁 فتح", GRAY) { openSelected() })
        row2.addView(btn("🗑 حذف نهائي", RED) { deleteSelected() })
        val bioOn = Bio.enabled(this)
        val row3 = btn(if (bioOn) "👆 إيقاف البصمة" else "👆 تفعيل فتح التطبيق بالبصمة", GRAY, true) {
            if (bioOn) { Bio.disable(this); toast("تم إيقاف البصمة"); showVault() } else enableBio()
        }
        r.addView(row1)
        r.addView(row2)
        r.addView(row3)
        setContentView(r)
        refresh()
    }

    private fun icon(mime: String) = when {
        mime.startsWith("image/") -> "🖼"
        mime.startsWith("video/") -> "🎬"
        mime.startsWith("audio/") -> "🎵"
        else -> "📄"
    }

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.1f GB".format(b / 1073741824.0)
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1024 -> "${b / 1024} KB"
        else -> "$b B"
    }

    private fun refresh() {
        Thread {
            val l = try { Vault.list(this) } catch (_: Exception) { emptyList() }
            runOnUiThread {
                items = l
                list.adapter = ArrayAdapter(
                    this, android.R.layout.simple_list_item_multiple_choice,
                    l.map { "${icon(it.mime)} ${it.name}  (${fmt(it.size)})" }
                )
                countTv.text = if (l.isEmpty()) "مفيش ملفات مخفية — اضغط \"إخفاء ملفات\"" else "الملفات المخفية: ${l.size} — حدّد الملفات ثم اختر إجراء"
            }
        }.start()
    }

    private fun selected(): List<Vault.Meta> {
        val s = list.checkedItemPositions
        val res = ArrayList<Vault.Meta>()
        for (i in 0 until s.size()) {
            if (s.valueAt(i)) items.getOrNull(s.keyAt(i))?.let { res.add(it) }
        }
        return res
    }

    private fun work(msg: String, job: () -> Unit, done: () -> Unit = {}) {
        val d = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
        Thread {
            try { job() } catch (e: Exception) { runOnUiThread { toast("خطأ: ${e.message}") } }
            runOnUiThread { d.dismiss(); done() }
        }.start()
    }

    // ---------------- إخفاء ----------------

    private fun pickFiles() {
        busy = true
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_PICK)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_PICK -> if (res == RESULT_OK && data != null) {
                val uris = ArrayList<Uri>()
                data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
                if (uris.isEmpty()) data.data?.let { uris.add(it) }
                if (Vault.key != null) hide(uris)
            }
            REQ_DELETE -> toast(if (res == RESULT_OK) "تم حذف النسخ الأصلية من المعرض ✅" else "النسخ الأصلية لسه موجودة في المعرض — احذفها يدويًا")
        }
    }

    private fun info(u: Uri): Triple<String, Long, String> {
        var name: String? = null
        var size = 0L
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0) name = c.getString(n)
                if (s >= 0) size = c.getLong(s)
            }
        }
        val mime = contentResolver.getType(u) ?: "application/octet-stream"
        return Triple(name ?: "file_${System.currentTimeMillis()}", size, mime)
    }

    private fun tryDelete(u: Uri): Boolean {
        try { if (DocumentsContract.deleteDocument(contentResolver, u)) return true } catch (_: Exception) {}
        try { if (contentResolver.delete(u, null, null) > 0) return true } catch (_: Exception) {}
        return false
    }

    private fun toMediaUri(u: Uri): Uri? {
        if (u.authority != "com.android.providers.media.documents") return null
        return try {
            val p = DocumentsContract.getDocumentId(u).split(":")
            if (p.size != 2) return null
            val base = when (p[0]) {
                "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else -> null
            }
            base?.let { ContentUris.withAppendedId(it, p[1].toLong()) }
        } catch (_: Exception) { null }
    }

    private fun hide(uris: List<Uri>) {
        var ok = 0
        var fail = 0
        var manual = 0
        val toDel = ArrayList<Uri>()
        work("جاري التشفير والإخفاء...", {
            for (u in uris) {
                try {
                    val (name, size, mime) = info(u)
                    contentResolver.openInputStream(u)!!.use { Vault.encrypt(this, it, name, mime, size) }
                    ok++
                    if (!tryDelete(u)) {
                        val mu = toMediaUri(u)
                        if (mu != null) toDel.add(mu) else manual++
                    }
                } catch (e: Exception) { fail++ }
            }
        }, {
            refresh()
            var msg = "تم إخفاء $ok ملف"
            if (fail > 0) msg += " — فشل $fail"
            if (manual > 0) msg += " — $manual ملف لازم تحذف الأصل منه يدويًا"
            toast(msg)
            if (toDel.isNotEmpty()) askDelete(toDel)
        })
    }

    private fun askDelete(uris: List<Uri>) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                busy = true
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } catch (e: Exception) {
                toast("احذف النسخ الأصلية من المعرض يدويًا")
            }
        } else {
            var n = 0
            for (u in uris) try { if (contentResolver.delete(u, null, null) > 0) n++ } catch (_: Exception) {}
            if (n < uris.size) toast("احذف النسخ الأصلية من المعرض يدويًا")
        }
    }

    // ---------------- إلغاء الإخفاء / فتح / حذف ----------------

    private fun restoreSelected() {
        val sel = selected()
        if (sel.isEmpty()) return toast("حدّد ملف واحد على الأقل")
        var ok = 0
        var fail = 0
        work("جاري إلغاء الإخفاء...", {
            for (m in sel) {
                try { if (Vault.restore(this, m)) ok++ else fail++ } catch (e: Exception) { fail++ }
            }
        }, {
            refresh()
            toast("تم إرجاع $ok ملف (صور→Pictures، فيديو→Movies، الباقي→Download)" + if (fail > 0) " — فشل $fail" else "")
        })
    }

    private fun openSelected() {
        val m = selected().singleOrNull() ?: return toast("حدّد ملف واحد فقط لفتحه")
        var out: File? = null
        work("جاري الفتح...", {
            val dir = File(cacheDir, "open").apply { mkdirs() }
            val f = File(dir, m.name.replace("/", "_"))
            Vault.open(m.file).stream.use { ins -> f.outputStream().use { ins.copyTo(it) } }
            out = f
        }, {
            out?.let { f ->
                try {
                    val uri = FileProvider.getUriForFile(this, "$packageName.provider", f)
                    busy = true
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, m.mime)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                } catch (e: Exception) {
                    busy = false
                    toast("مفيش تطبيق يقدر يفتح الملف ده")
                }
            }
        })
    }

    private fun deleteSelected() {
        val sel = selected()
        if (sel.isEmpty()) return toast("حدّد ملف واحد على الأقل")
        AlertDialog.Builder(this)
            .setMessage("حذف ${sel.size} ملف نهائيًا؟ مش هتقدر ترجعهم.")
            .setPositiveButton("حذف") { _, _ -> sel.forEach { it.file.delete() }; refresh() }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
