# eM Hide
تطبيق أندرويد لإخفاء الملفات والصور والفيديوهات بكلمة سر (تشفير AES-256).
- الحد الأدنى: Android 10 (API 29)
- البناء: ارفع ملف الـ zip على GitHub مع .github/workflows/build.yml
